
libdasm examples
================

In this directory, there should be files Makefile, das.c, and
simple.c. simple.c is a very basic example disassembler which
basically just disassembles and prints out one instruction. das.c
is more complex example which can be used for disassembling a
file with some formatting options. On unix systems, you can use
supplied Makefile for compiling these examples.

Have fun!


