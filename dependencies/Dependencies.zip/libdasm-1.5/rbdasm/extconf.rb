require 'mkmf'
create_makefile('dasm')
