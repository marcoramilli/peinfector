peutils (c) 2002 Andrew de Quincey
Distributed under a BSD-style license. See LICENSE.TXT for more details.
http://peutils.sourceforge.net/


----------------------------------
Info:

This is a suite of utilities for manipulating PE-format executables.


----------------------------------
Usage:

The following uses a hypothetical executable, called "peexe.exe".

To split a PE file up into sections and configuration file, type:
       pesplit peexe.exe

A number of .bin files will be created, one for each section, along with
a file "peexe.exe.pe", which contains the various flags from the original
PE-executable, as well as indicating which .bin file contains which 
sections. A file, "dosstub.bin" will also be generated to contain the DOS EXE
stub header.


To join a PE file again, type:
       pejoin peexe.exe.pe peexe.exe

The executable peexe.exe will be regenerated from the configuration file,
"peexe.exe.pe", and the various .bin files it references


----------------------------------
Notes:

The confguration file - the .pe file - has the following structure:

A set of sections: PEHeader, NTOptionalHeader, DataDirectories, and Sections.
In the file, these must be hard-left; i.e. no white space should be present 
before them.

Each section has a number of entries, for example the PEHeader section
has a "cpuType" entry. These should have at least one whitespace before
them.

When joining an executable, no error checking of the values you supply in 
the configuration file is done - they are simply copied straight into the 
destination executable. This was done to allow maximum flexibility.

The rest of the format should be obvious when looking at the configuration file
for a pesplit executable.


----------------------------------
Problems:

Leaving entries out of the configuration file may cause problems.
